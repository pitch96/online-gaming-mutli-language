<div class="widget-sidebar">
	<?php widget_aside('sidebar-1') ?>
</div>