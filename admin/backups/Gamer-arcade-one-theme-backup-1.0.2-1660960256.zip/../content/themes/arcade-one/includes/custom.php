<?php

/*

Used for custom Widgets and custom Widget placements

This file will not be overwritten by the updater

*/

?>